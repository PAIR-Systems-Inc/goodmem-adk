import os

import pytest
from support import LiveServer

from goodmem_adk import tools as tools_module


@pytest.fixture(autouse=True)
def isolated_configuration(monkeypatch):
    for name in ("GOODMEM_SPACE_ID", "GOODMEM_SPACE_NAME", "GOODMEM_EMBEDDER_ID"):
        monkeypatch.delenv(name, raising=False)
    yield
    for client in tools_module._client_cache.values():
        client.close()
    tools_module._client_cache.clear()


@pytest.fixture
def live(monkeypatch):
    if os.environ.get("ADK_AUDIT_LIVE") != "1":
        pytest.skip("Set ADK_AUDIT_LIVE=1 to use the local GoodMem test server")
    server = LiveServer(monkeypatch)
    try:
        yield server
    finally:
        server.close()
