"""Real provider decisions, actual ADK runners, and live GoodMem retrieval."""

import asyncio
import os

import pytest
from fpdf import FPDF
from google.adk.agents import LlmAgent
from google.adk.apps import App
from google.adk.runners import InMemoryRunner
from support import all_text, append_evidence, responses, turn, unique

from goodmem_adk import GoodmemClient, GoodmemFetchTool, GoodmemPlugin, GoodmemSaveTool

pytestmark = pytest.mark.asyncio


def model():
    identifier = os.environ.get("ADK_AUDIT_MODEL")
    if not identifier:
        pytest.skip("ADK_AUDIT_MODEL must select an authenticated real model")
    if identifier.startswith("cohere_chat/"):
        from google.adk.models.lite_llm import LiteLlm

        return LiteLlm(model=identifier, temperature=0, max_tokens=512)
    return identifier


def final_text(events):
    return " ".join(
        part.text
        for event in events
        if event.is_final_response() and event.content
        for part in (event.content.parts or [])
        if part.text
    )


@pytest.mark.parametrize("path", ["plugin", "tools"])
async def test_provider_recalls_exact_random_fact_in_new_session(live, path):
    plugin = GoodmemPlugin(**live.config) if path == "plugin" else None
    tool_list = (
        [GoodmemSaveTool(**live.config), GoodmemFetchTool(**live.config)] if path == "tools" else []
    )
    agent = LlmAgent(
        name="memory_audit_agent",
        model=model(),
        tools=tool_list,
        instruction=(
            "Help the user remember their personal project facts. "
            "When memory tools are available, use goodmem_save when asked to remember "
            "a fact and goodmem_fetch when asked to recall it. Otherwise use the supplied "
            "memory context. Report errors honestly. Never invent a missing identifier. "
            "Keep replies brief and reproduce identifiers exactly."
        ),
    )
    app = App(name=unique("realapp"), root_agent=agent, plugins=[plugin] if plugin else [])
    runner = InMemoryRunner(app=app)
    user, fact = unique("realuser"), unique("orchid")
    evidence = {"model": os.environ["ADK_AUDIT_MODEL"], "path": path, "fact": fact}
    try:
        first, events = await turn(
            runner, user, f"Please remember this exact fact: my collection label is {fact}."
        )
        evidence["save_response"] = final_text(events)
        evidence["save_tools"] = responses(events, "goodmem_save")
        if path == "tools":
            assert evidence["save_tools"] and evidence["save_tools"][0]["success"], evidence
        await live.wait_for_writes()
        second, events = await turn(
            runner,
            user,
            "What is my collection label? Consult memory and give the exact identifier.",
        )
        assert first != second
        evidence["recall_response"] = final_text(events)
        evidence["fetch_tools"] = responses(events, "goodmem_fetch")
        if path == "tools":
            assert evidence["fetch_tools"] and fact in all_text(evidence["fetch_tools"]), evidence
        assert fact in evidence["recall_response"], evidence
        _, events = await turn(
            runner,
            unique("unrelateduser"),
            "What is my collection label? Consult memory and give the exact identifier.",
        )
        evidence["other_user_response"] = final_text(events)
        assert fact not in evidence["other_user_response"], evidence
    finally:
        await runner.close()
        if plugin:
            plugin.goodmem_client.close()
        target = os.environ.get("ADK_AUDIT_MODEL_EVIDENCE")
        if target:
            await asyncio.to_thread(append_evidence, target, evidence)


@pytest.mark.parametrize("path", ["plugin", "tools"])
async def test_provider_answers_from_pdf_extracted_by_goodmem(live, path):
    """The provider receives retrieved text; GoodMem receives the binary PDF."""
    sid, fact = live.new_space(), unique("dock")
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Helvetica", size=12)
    pdf.multi_cell(0, 8, f"Receiving instructions. The assigned loading dock identifier is {fact}.")
    with GoodmemClient(live.base_url, live.api_key) as client:
        client.insert_memory_binary(sid, bytes(pdf.output()), "application/pdf")
    await live.wait_for_writes()
    plugin = GoodmemPlugin(**live.config, space_id=sid) if path == "plugin" else None
    agent = LlmAgent(
        name="pdf_audit_agent",
        model=model(),
        tools=[GoodmemFetchTool(**live.config, space_id=sid)] if path == "tools" else [],
        instruction="Answer from memory. Use goodmem_fetch if available. Copy identifiers exactly; never guess.",
    )
    runner = InMemoryRunner(
        app=App(name=unique("pdfapp"), root_agent=agent, plugins=[plugin] if plugin else [])
    )
    evidence = {
        "model": os.environ["ADK_AUDIT_MODEL"],
        "path": path,
        "case": "PDF extracted by GoodMem",
        "fact": fact,
    }
    try:
        _, events = await turn(
            runner,
            unique("pdfuser"),
            "What is the assigned loading dock identifier? Look in memory.",
        )
        evidence["response"] = final_text(events)
        evidence["fetch_tools"] = responses(events, "goodmem_fetch")
        assert fact in evidence["response"], evidence
        if path == "tools":
            assert evidence["fetch_tools"] and fact in all_text(evidence["fetch_tools"]), evidence
    finally:
        await runner.close()
        if plugin:
            plugin.goodmem_client.close()
        target = os.environ.get("ADK_AUDIT_MODEL_EVIDENCE")
        if target:
            await asyncio.to_thread(append_evidence, target, evidence)
