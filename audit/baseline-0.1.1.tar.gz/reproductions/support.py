"""Audit helpers: real ADK runners, synthetic facts, and recorded HTTP traffic."""

import asyncio
import json
import os
import uuid
from pathlib import Path

import httpx
from google.adk.agents import LlmAgent
from google.adk.apps import App
from google.adk.models.base_llm import BaseLlm
from google.adk.models.llm_response import LlmResponse
from google.adk.runners import InMemoryRunner
from google.genai import types
from pydantic import Field


def unique(prefix="adk_audit"):
    return f"{prefix}_{uuid.uuid4().hex[:12]}"


def append_evidence(path, evidence):
    with open(path, "a") as file:
        file.write(all_text(evidence) + "\n")


def text_content(text):
    return types.Content(role="user", parts=[types.Part(text=text)])


def all_text(value):
    return json.dumps(
        value,
        ensure_ascii=False,
        default=lambda item: (
            item.model_dump(mode="json", exclude_none=True)
            if hasattr(item, "model_dump")
            else str(item)
        ),
    )


class RecordingModel(BaseLlm):
    """Deterministic model boundary; ADK callbacks and tools execute normally.

    A SAVE/FETCH directive causes one real ADK tool call. Otherwise the model
    acknowledges the message. Requests are copied so tests inspect exactly what
    reached the model, rather than accepting a plausible generated answer.
    """

    model: str = "audit-recording-model"
    requests: list = Field(default_factory=list)

    async def generate_content_async(self, llm_request, stream=False):
        self.requests.append(llm_request.model_copy(deep=True))
        last = llm_request.contents[-1]
        if any(part.function_response for part in (last.parts or [])):
            yield LlmResponse(
                content=types.Content(
                    role="model", parts=[types.Part(text="Tool response received.")]
                )
            )
            return
        text = " ".join(part.text for part in (last.parts or []) if part.text)
        for directive, name, argument in [
            ("SAVE:", "goodmem_save", "content"),
            ("FETCH:", "goodmem_fetch", "query"),
            ("LOAD:", "load_memory", "query"),
        ]:
            if text.startswith(directive):
                # Plugin-added memory is context, not an additional directive.
                value = text[len(directive) :].split("\n\nBEGIN MEMORY")[0].strip()
                yield LlmResponse(
                    content=types.Content(
                        role="model",
                        parts=[
                            types.Part(
                                function_call=types.FunctionCall(name=name, args={argument: value})
                            )
                        ],
                    )
                )
                return
        yield LlmResponse(
            content=types.Content(role="model", parts=[types.Part(text="Acknowledged.")])
        )


def runner_for(*, plugin=None, tools=None, model=None, app_name=None):
    model = model or RecordingModel()
    app = App(
        name=app_name or unique("auditapp"),
        root_agent=LlmAgent(name="audit_agent", model=model, tools=tools or []),
        plugins=[plugin] if plugin else [],
    )
    return InMemoryRunner(app=app), model


async def turn(runner, user_id, message, session_id=None):
    if session_id is None:
        session = await runner.session_service.create_session(
            app_name=runner.app_name, user_id=user_id
        )
        session_id = session.id
    events = [
        event
        async for event in runner.run_async(
            user_id=user_id,
            session_id=session_id,
            new_message=text_content(message) if isinstance(message, str) else message,
        )
    ]
    return session_id, events


def responses(events, name):
    found = [
        part.function_response.response
        for event in events
        if event.content
        for part in (event.content.parts or [])
        if part.function_response and part.function_response.name == name
    ]
    # ADK wraps non-dict FunctionTool results in {"result": ...}.
    normalized = []
    for result in found:
        if set(result) == {"result"}:
            result = result["result"]
        if hasattr(result, "model_dump"):
            result = result.model_dump(mode="json")
        normalized.append(result)
    return normalized


class LiveServer:
    """Use existing test credentials; record and clean up only this run's writes."""

    def __init__(self, monkeypatch):
        runtime = Path(
            os.environ.get(
                "ADK_AUDIT_RUNTIME",
                "/home/amin/clients/pairsys/Agentic_RAG_GoodMem/.runtime",
            )
        )
        credentials = json.loads((runtime / "credentials.json").read_text())
        state = json.loads((runtime / "state.json").read_text())
        self.base_url = credentials["base_url"]
        assert self.base_url in ("http://localhost:8088", "http://127.0.0.1:8088")
        self.api_key = credentials["api_key"]
        self.embedder_id = state["embedder_id"]
        self.spaces = {}
        self.writes = []
        self.requests = []
        original_send = httpx.Client.send

        def observe(client, request, *args, **kwargs):
            response = original_send(client, request, *args, **kwargs)
            if str(request.url).startswith(self.base_url + "/"):
                self.requests.append((request.method, request.url.path, response.status_code))
                if request.method == "POST" and response.is_success:
                    if request.url.path == "/v1/spaces":
                        result = response.json()
                        self.spaces[result["spaceId"]] = result["name"]
                    elif request.url.path == "/v1/memories":
                        result = response.json()
                        self.writes.append(result)
            return response

        monkeypatch.setattr(httpx.Client, "send", observe)
        self.http = httpx.Client(
            base_url=self.base_url, headers={"x-api-key": self.api_key}, timeout=30
        )

    @property
    def config(self):
        return {"base_url": self.base_url, "api_key": self.api_key, "embedder_id": self.embedder_id}

    def new_space(self, name=None, chunk_size=None):
        chunking = (
            {"none": {}}
            if chunk_size is None
            else {
                "recursive": {
                    "chunkSize": chunk_size,
                    "chunkOverlap": 0,
                    "keepStrategy": "KEEP_END",
                    "lengthMeasurement": "CHARACTER_COUNT",
                }
            }
        )
        response = self.http.post(
            "/v1/spaces",
            json={
                "name": name or unique(),
                "spaceEmbedders": [{"embedderId": self.embedder_id}],
                "defaultChunkingConfig": chunking,
            },
        )
        response.raise_for_status()
        return response.json()["spaceId"]

    async def wait_for_writes(self):
        # Observe accepted IDs, never infer indexing from an empty search.
        for written in list(self.writes):
            deadline = asyncio.get_running_loop().time() + 60
            while True:
                response = await asyncio.to_thread(
                    self.http.get, "/v1/memories/" + written["memoryId"]
                )
                response.raise_for_status()
                status = response.json()["processingStatus"]
                if status == "COMPLETED":
                    break
                assert status != "FAILED", f"Indexing failed for {written['memoryId']}"
                assert asyncio.get_running_loop().time() < deadline, "Indexing timeout"
                await asyncio.sleep(0.2)

    def close(self):
        cleanup = []
        try:
            for sid, name in self.spaces.items():
                response = self.http.delete("/v1/spaces/" + sid)
                cleanup.append({"space_id": sid, "name": name, "status": response.status_code})
                assert response.status_code in (200, 204, 404), cleanup[-1]
        finally:
            self.http.close()
            evidence = os.environ.get("ADK_AUDIT_EVIDENCE")
            if evidence:
                with open(evidence, "a") as file:
                    file.write(
                        json.dumps(
                            {
                                "cleanup": cleanup,
                                "requests": self.requests,
                                "accepted_memory_ids": [w["memoryId"] for w in self.writes],
                            }
                        )
                        + "\n"
                    )
